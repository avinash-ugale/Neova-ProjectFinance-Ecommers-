package com.example.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

    @Entity
    @Table(name="")
    public class Product {

            @Id
			@Column(name="PRODUCT_ID")
			private int Productid;
			
			
			@Column(name="PRODUCT_NAME")
			private String ProductName;
			
			@Column(name="PRODUCT_DETAILS")
			private String ProductDetails;
			
			@Column(name="PRODUCT_COST")
			private int ProductCost;

			public int getProductid() {
				return Productid;
			}

			public void setProductid(int productid) {
				Productid = productid;
			}

			public String getProductName() {
				return ProductName;
			}

			public void setProductName(String productName) {
				ProductName = productName;
			}

			public String getProductDetails() {
				return ProductDetails;
			}

			public void setProductDetails(String productDetails) {
				ProductDetails = productDetails;
			}

			public int getProductCost() {
				return ProductCost;
			}

			public void setProductCost(int productCost) {
				ProductCost = productCost;
			}

			@Override
			public String toString() {
				return "Product [Productid=" + Productid + ", ProductName=" + ProductName + ", ProductDetails="
						+ ProductDetails + ", ProductCost=" + ProductCost + "]";
			}
			
		    

            
		    

	}


