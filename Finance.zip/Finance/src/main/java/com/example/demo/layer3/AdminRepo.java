package com.example.demo.layer3;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.User;

public interface AdminRepo extends JpaRepository<Admin,Integer> {

	void save(User uobj);

}
