package com.example.demo.layer4;

public interface UserLogin {
	boolean userLogin( int userId,String password);
}
