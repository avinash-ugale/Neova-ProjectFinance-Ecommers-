package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.EMICard;
@Repository
public class EMICardRepoImpl extends BaseRepository implements EMICardRepo {

	@Transactional
	public void insertEMICard(EMICard emicardObj) {
          super.persist(emicardObj);

	}

	@Override
	public EMICard selectEmiCard(int emiCardNumber) {
         EMICard emiCard =super.find(EMICard.class, emiCardNumber);
         return emiCard;
		}

	@Override
	public List<EMICard> selectEmiCard() {
		List<EMICard> listEMICard = new ArrayList<>();
		return super.findAll("EMICard");
		
		
	}

	@Transactional
	public void updateEmiCard(EMICard emiCardObj) {
		super.merge(emiCardObj);// TODO Auto-generated method stub

	}

	@Transactional
	public void deleteEmiCard(int emiCardNumber) {
        super.remove(EMICard.class,emiCardNumber);		// TODO Auto-generated method stub

	}

}
