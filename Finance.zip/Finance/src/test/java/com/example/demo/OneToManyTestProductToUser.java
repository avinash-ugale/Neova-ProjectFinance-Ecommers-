package com.example.demo;

import java.time.LocalDate;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Orders;
import com.example.demo.layer2.Product;
import com.example.demo.layer2.User;
import com.example.demo.layer3.OrdersRepoImpl;
import com.example.demo.layer3.ProductRepoImpl;
import com.example.demo.layer3.UserRepoImpl;



		@SpringBootTest
		public class OneToManyTestProductToUser {
		
			@Autowired
			UserRepoImpl user;
			@Autowired
			ProductRepoImpl product;
			
		
		
		@Test
		void OneToManyTests() {
		
		Product passObj1 = product.selectProduct(58);
	
		
		User passObj2 = new User();
		
		passObj2.setProductId(passObj1);
		
		user.insertUser(passObj2);

}

}