package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.PaymentAndInstallment;
@Repository
public interface PaymentAndInstallmentRepo {

		void insertInstallment(PaymentAndInstallment installmentobj); // C

		PaymentAndInstallment selectInstallment(int installmentNo); // R

		List<PaymentAndInstallment> selectInstallment(); // RA

		void updateInstallment(PaymentAndInstallment installmentobj); // U

		void deleteInstallment(int installmentNo); // D
	}


