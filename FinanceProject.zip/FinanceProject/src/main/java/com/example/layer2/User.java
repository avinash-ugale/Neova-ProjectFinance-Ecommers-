package com.example.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.example.layer2.Emi;


@Entity
@Table(name="UserTable")

public class User {
	    
	    @Id
		@Column(name="USER_ID")
		private int UserId;

		@Column(name="USER_NAME")
		private String UserName;
		
		
		@Column(name="DATE_OF_BIRTH")
		private LocalDate dob;
		
	
		@Column(name="PHONE_NO")
		private long PhoneNo;
		
		@Column(name="EMAIL")
		private String Email;
		
		@Column(name="ADDRESS")
		private String Address;
		
		@Column(name="PAN_CARD")
		private int PanCardno;
		
		
		@Column(name="CIBIL_SCORE")
		private int CibilScore;
		
		@Column(name="BANK_NAME")
		private String BankName;
		
		@Column(name="IFSC")
		private int ifsc;
		
		@Column(name="ACCOUNT_NO")
		private long AccountNo;
        
		
		@Column(name="ACCOUNT_STATUS")
		private long AccountStatus;

		
		//One to one relation for Emi
		@OneToOne
		private Emi emi;
		
		public Emi getEmi() {
			return emi;
		}

		public void setEmi(Emi emi) {
			this.emi = emi;
		}
		
		//one to one realtion for EMicard
		@OneToOne
		private EmiCard emicard;
		

		public EmiCard getEmicard() {
			return emicard;
		}

		public void setEmicard(EmiCard emicard) {
			this.emicard = emicard;
		}

		public int getUserId() {
			return UserId;
		}

		public void setUserId(int userId) {
			UserId = userId;
		}

		public String getUserName() {
			return UserName;
		}

		public void setUserName(String userName) {
			UserName = userName;
		}

		public LocalDate getDob() {
			return dob;
		}

		public void setDob(LocalDate dob) {
			this.dob = dob;
		}

		public long getPhoneNo() {
			return PhoneNo;
		}

		public void setPhoneNo(long phoneNo) {
			PhoneNo = phoneNo;
		}

		public String getEmail() {
			return Email;
		}

		public void setEmail(String email) {
			Email = email;
		}

		public String getAddress() {
			return Address;
		}

		public void setAddress(String address) {
			Address = address;
		}
		public int getPanCardno() {
			return PanCardno;
		}


		public void setPanCardno(int panCardno) {
			PanCardno = panCardno;
		}


		public int getCibilScore() {
			return CibilScore;
		}


		public void setCibilScore(int cibilScore) {
			CibilScore = cibilScore;
		}


		public String getBankName() {
			return BankName;
		}


		public void setBankName(String bankName) {
			BankName = bankName;
		}


		public int getIfsc() {
			return ifsc;
		}


		public void setIfsc(int ifsc) {
			this.ifsc = ifsc;
		}


		public long getAccountNo() {
			return AccountNo;
		}


		public void setAccountNo(long accountNo) {
			AccountNo = accountNo;
		}


		public long getAccountStatus() {
			return AccountStatus;
		}


		public void setAccountStatus(long accountStatus) {
			AccountStatus = accountStatus;
		}

		@Override
		public String toString() {
			return "User [UserId=" + UserId + ", UserName=" + UserName + ", dob=" + dob + ", PhoneNo=" + PhoneNo
					+ ", Email=" + Email + ", Address=" + Address + ", PanCardno=" + PanCardno + ", CibilScore="
					+ CibilScore + ", BankName=" + BankName + ", ifsc=" + ifsc + ", AccountNo=" + AccountNo
					+ ", AccountStatus=" + AccountStatus + ", emi=" + emi + "]";
		}

		
		
	    

}
