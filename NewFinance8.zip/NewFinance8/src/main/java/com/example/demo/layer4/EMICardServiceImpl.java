package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.EMICard;
import com.example.demo.layer3.EMICardRepoImpl;

public class EMICardServiceImpl implements EMICardService {
	EMICardRepoImpl emiCardRepo;
	@Override
	public void createEMICardService(EMICard emiCardObj) {
		// TODO Auto-generated method stub
		emiCardRepo.insertEMICard(emiCardObj);
	}

	@Override
	public List<EMICard> findAllEMICardService() {
		// TODO Auto-generated method stub
		return emiCardRepo.findAll("EMICard");
	}

	@Override
	public EMICard findEMICardService(int emiCardNo) {
		// TODO Auto-generated method stub
		return emiCardRepo.selectEmiCard(emiCardNo);
	}

	@Override
	public void modifyEMICardService(EMICard emiCardObj) {
		// TODO Auto-generated method stub
		emiCardRepo.updateEmiCard(emiCardObj);
	}

	@Override
	public void removeEMICardService(int emiCardNo) {
		// TODO Auto-generated method stub
		emiCardRepo.deleteEmiCard(emiCardNo);
	}

}
