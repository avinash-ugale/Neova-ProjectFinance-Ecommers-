package com.example.demo.layer4;

public interface BuyProduct {
		
	void buyproduct(int productId, int emiSchemeId);
}
