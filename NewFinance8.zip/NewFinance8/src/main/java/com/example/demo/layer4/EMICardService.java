package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.EMICard;
import com.example.demo.layer2.Orders;
import com.example.demo.layer2.User;

public interface EMICardService {
	void createEMICardService(EMICard emiCardObj) ; //C
	List<EMICard> findAllEMICardService(); //RA
	
	EMICard findEMICardService(int emiCardNo);
	void modifyEMICardService(EMICard emiCardObj); //C
	void removeEMICardService(int emiCardNo); //C
}
