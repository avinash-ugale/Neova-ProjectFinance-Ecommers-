package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.User;
import com.example.demo.layer4.UserServiceImpl;
@RestController
@RequestMapping("/User")
public class UserController {
	
	@Autowired
	private UserServiceImpl userService;

	@GetMapping("/list") // localhost:8080/Student/list/1
	public List<User> getAllUser() {
		return userService.findAllUserService();

	}

	@GetMapping(value = "/get/{id}")
	public  User getUserById (@PathVariable int id) {
		return userService.findUserService(id);
	}
	
	 @PostMapping(value = "/add")
	 public void saveUser(@RequestBody User userObj) {
		 userService.createUserService(userObj);
	 }
	 
	 @PutMapping(value = "/update/{id}")
	 public void updateUserDetails(@RequestBody User userObj,@PathVariable int id ) {
		userService.modifyUserService(id, userObj);
	 }
	 
	 @DeleteMapping(value = "/delete/{id}")
	 public void deleteUser(@PathVariable int id) {
      userService.removeUserService(id);		 	 
	 }
}
