package com.example.demo.layer4;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.EMI;
import com.example.demo.layer2.Product;
import com.example.demo.layer3.EMIRepo;
import com.example.demo.layer3.ProductRepoImpl;

public class BuyProductImpl implements BuyProduct {
	@Autowired
	ProductRepoImpl p;
	@Autowired
	EMIRepo emi;
	
	@Override
	public void buyproduct(int productId, int emiSchemeId) {
		
		Product product = p.selectProduct(productId);
		EMI emiScheme=emi.selectEMI(emiSchemeId);
		
		
	}

}
