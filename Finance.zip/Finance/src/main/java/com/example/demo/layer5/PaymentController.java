package com.example.demo.layer5;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.layer2.PaymentAndInstallment;

import com.example.demo.layer3.PaymentAndInstallmentRepoImpl;



@RestController
@RequestMapping("/payment")
public class PaymentController {

	@Autowired
	PaymentAndInstallmentRepoImpl paymentRepo;
	
	@RequestMapping("/getpayment/{installmentNo}")//localhost:8080/payment/getpayment/36
	public PaymentAndInstallment getpayment(@PathVariable("installmentNo") int installmentNo)
	{
		PaymentAndInstallment payment = null;
		payment=paymentRepo.selectInstallment(installmentNo);
		
		System.out.println("controller : emi : "+payment.getEmiInstallmentNumber());
		return payment;
	}
	@RequestMapping("/getAll")//localhost:8080/orders/getAll
	public List<PaymentAndInstallment> getpayment()
	{
		System.out.println("getAll");
		List<PaymentAndInstallment> paymentList;
		paymentList=paymentRepo.selectInstallment();
		return paymentList;
	}
	
		@PostMapping("/Add")
		public void addPayment(@RequestBody PaymentAndInstallment payment)
		{
		paymentRepo.insertInstallment(payment);
		}
	
		@PutMapping("/update")//http://localhost:8080/order/update
		public void updatePayment(@RequestBody PaymentAndInstallment payment)
		{
		paymentRepo.updateInstallment(payment);
		}
	
		@DeleteMapping("/delete/{installmentNo}")//http://localhost:8080/order/delete/45
		public String deletePayment(@PathVariable("installmentNo") int installmentNo)
		{
		paymentRepo.deleteInstallment(installmentNo);
		return "delete successfully";
		}

	}

