package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.User;
import com.example.demo.layer3.UserRepo;
import com.example.demo.layer3.UserRepoImpl;
@Service
public class UserServiceImpl implements UserService {

	UserRepoImpl userRepo;
	@Override
	public void createUserService(User userObj) {
		// TODO Auto-generated method stub
        userRepo.insertUser(userObj);
	}

	@Override
	public List<User> findAllUserService() {
		// TODO Auto-generated method stub
		return userRepo.findAll("User");
	}

	@Override
	public User findUserService(int userno) {
		// TODO Auto-generated method stub
		return userRepo.selectUser(userno);
	}

	@Override
	public void modifyUserService(int userNo,User userObj) {
		// TODO Auto-generated method stub
       User u1=userRepo.selectUser(userNo);
       u1=userObj;
        userRepo.updateUser(u1);
       
       
	}

	@Override
	public void removeUserService(int userNo) {
		// TODO Auto-generated method stub
           userRepo.deleteUser(userNo);
	}

}
