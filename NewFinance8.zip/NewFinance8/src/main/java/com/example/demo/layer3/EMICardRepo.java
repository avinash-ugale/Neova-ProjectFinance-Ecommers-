package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.EMICard;


@Repository
public interface EMICardRepo {
	void insertEMICard(EMICard emicardObj); // C

	EMICard selectEmiCard(int emiCardNumber); // R

	List<EMICard> selectEmiCard(); // RA

	void updateEmiCard(EMICard emiCardObj); // U

	void deleteEmiCard(int emiCardNumber); // D
}
