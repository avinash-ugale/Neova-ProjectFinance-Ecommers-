package com.example.demo.layer4;

import java.util.Set;

import com.example.demo.layer2.EMICard;
import com.example.demo.layer2.Orders;

public interface UserDashBoard {
		EMICard cardDetails(int userId);
		Set<Orders> ordersDetails();
		float remainingBalance();
}
