package com.example.demo;

import java.time.LocalDate;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.EMI;
import com.example.demo.layer2.EMICard;
import com.example.demo.layer3.EMICardRepo;




		@SpringBootTest
		public class OneToManyEmiCardToEmi {
		
			@Autowired
			EMICardRepo emiCard;
			@Autowired
			EMI emi;
			
		
		
		@Test
		void OneToManyTests() {
		
		EMICard passObj1 = emiCard.selectEmiCard(28);
		
		EMI passObj2 = new EMI();
		
		passObj2.setEmiCard(passObj1);
		
		emi.insertEMI(passObj2);

}

}