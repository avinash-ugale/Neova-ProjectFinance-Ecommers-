package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Orders;
@Repository
public interface OrdersRepo {
	void insertOrder(Orders ordersObj); // C

	Orders selectOrder(int ordersno); // R

	List<Orders> selectOrders(); // RA

	void updateOrders(Orders ordersObj); // U

	void deleteOrders(int ordersNo); // D
//	List <Orders> selectOrdersByUserId(int userId);
}
