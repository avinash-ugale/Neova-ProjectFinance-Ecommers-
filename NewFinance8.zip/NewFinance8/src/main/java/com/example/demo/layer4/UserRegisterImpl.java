package com.example.demo.layer4;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.EMICard;
import com.example.demo.layer2.User;
import com.example.demo.layer3.EMICardRepoImpl;
import com.example.demo.layer3.UserRepoImpl;

public class UserRegisterImpl implements UserRegister {
	@Autowired
	UserRepoImpl u;

	@Autowired
	EMICardRepoImpl c;

	@Override
	public int createUser(User userObject) {
		u.insertUser(userObject);
		return userObject.getUserId();
	}

	@Override
	public void selectEMICard(int userId, int cardId) {
		User user = u.selectUser(userId);
		EMICard card = c.selectEmiCard(cardId);
		user.setEmiCard(card);
		card.setUser(user);
		u.updateUser(user);
		c.updateEmiCard(card);

	}

}
