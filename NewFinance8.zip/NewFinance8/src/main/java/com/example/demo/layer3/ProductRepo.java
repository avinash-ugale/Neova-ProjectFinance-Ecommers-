package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Product;
@Repository
public interface ProductRepo {
	void insertProduct(Product productObj); // C

	Product selectProduct(int productNo); // R

	List<Product> selectProduct(); // RA

	void updateProduct(Product productObj); // U

	void deletePerson(int productNo); // D
}
