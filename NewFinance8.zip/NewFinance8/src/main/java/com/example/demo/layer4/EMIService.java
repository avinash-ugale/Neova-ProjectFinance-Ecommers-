package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.EMI;
import com.example.demo.layer2.EMICard;
@Service
public interface EMIService {
	void createEMIService(EMI emiObj) ; //C
	List<EMI> findAllEMIService(); //RA
	
	EMI findEMIService(int emiNo);
	void modifyEMIService(EMI emiObj); //C
	void removeEMIService(int emiNo); //C
}
