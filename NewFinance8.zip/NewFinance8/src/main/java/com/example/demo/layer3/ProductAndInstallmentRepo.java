package com.example.demo.layer3;

import java.util.List;

import com.example.demo.layer2.PaymentAndInstallment;

public interface ProductAndInstallmentRepo {
	void insertInstallmentNumber(PaymentAndInstallment installmentObj); // C

	PaymentAndInstallment selectInstallment(int installmentNo); // R

	List<PaymentAndInstallment> selectInstallment(); // RA

	void updateInstallment(PaymentAndInstallment installmentObj); // U

	void deleteInstallment(int installmentNo); // D
}
