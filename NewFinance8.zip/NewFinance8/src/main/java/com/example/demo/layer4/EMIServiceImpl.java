package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.EMI;
import com.example.demo.layer3.EMIRepoImpl;

public class EMIServiceImpl implements EMIService {
	EMIRepoImpl emiRepo;
	@Override
	public void createEMIService(EMI emiObj) {
		// TODO Auto-generated method stub
		emiRepo.insertEMI(emiObj);
	}

	@Override
	public List<EMI> findAllEMIService() {
		// TODO Auto-generated method stub
		return emiRepo.findAll("EMI");
	}

	@Override
	public EMI findEMIService(int emiNo) {
		// TODO Auto-generated method stub
		return emiRepo.selectEMI(emiNo);
	}

	@Override
	public void modifyEMIService(EMI emiObj) {
		// TODO Auto-generated method stub
		emiRepo.updateEMI(emiObj);
	}

	@Override
	public void removeEMIService(int emiNo) {
		// TODO Auto-generated method stub
		emiRepo.deleteEMI(emiNo);
	}

}
