package com.example.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

    @Entity
    @Table(name="")
    public class Admin {

            @Id
			@Column(name="ADMIN_ID")
			private int AdminId;
			
			
			@Column(name="ADMIN_PASSWORD")
			private String AdminPassword;


			public int getAdminId() {
				return AdminId;
			}


			public void setAdminId(int adminId) {
				AdminId = adminId;
			}


			public String getAdminPassword() {
				return AdminPassword;
			}


			public void setAdminPassword(String adminPassword) {
				AdminPassword = adminPassword;
			}


			@Override
			public String toString() {
				return "Admin [AdminId=" + AdminId + ", AdminPassword=" + AdminPassword + "]";
			}
			
    }