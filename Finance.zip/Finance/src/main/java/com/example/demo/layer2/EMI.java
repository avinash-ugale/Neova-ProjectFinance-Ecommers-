package com.example.demo.layer2;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="emi_tb")
public class EMI {

	

	public EMI() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EMI(float remainingBalance, LocalDate expirationDate) {
		super();
		this.remainingBalance = remainingBalance;
		this.expirationDate = expirationDate;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)	
	private int  emiCardNo;
	private	float remainingBalance;
	private	LocalDate expirationDate;
	
	@OneToOne//(mappedBy = "emiCardNumber",cascade = CascadeType.ALL)
	private User user;
	
	@OneToMany(mappedBy = "emiCardNumber", cascade = CascadeType.ALL)
	private Set<PaymentAndInstallment> userEMIInstallmentSet = new HashSet<PaymentAndInstallment>();
	
	
	public Set<PaymentAndInstallment> getUserEMIInstallmentSet() {
		return userEMIInstallmentSet;
	}

	public void setUserEMIInstallmentSet(Set<PaymentAndInstallment> userEMIInstallmentSet) {
		this.userEMIInstallmentSet = userEMIInstallmentSet;
	}

	public EMI getEmiId() {
		return emiId;
	}

	public void setEmiId(EMI emiId) {
		this.emiId = emiId;
	}

	@ManyToOne
	private EMI emiId;
	@ManyToOne
	private EMICard emiCard;

	



public int getEmiCardNo() {
	return emiCardNo;
}

public void setEmiCardNo(int emiCardNo) {
	this.emiCardNo = emiCardNo;
}

public float getRemainingBalance() {
	return remainingBalance;
}

public void setRemainingBalance(float remainingBalance) {
	this.remainingBalance = remainingBalance;
}

public LocalDate getExpirationDate() {
	return expirationDate;
}

public void setExpirationDate(LocalDate expirationDate) {
	this.expirationDate = expirationDate;
}

public User getUser() {
	return user;
}

public void setUser(User user) {
	this.user = user;
}

public EMICard getEmiCard() {
	return emiCard;
}

public void setEmiCard(EMICard emiCard) {
	this.emiCard = emiCard;
}

public void insertEMI(EMI passObj2) {
	// TODO Auto-generated method stub
	
}





}
