package com.example.demo.layer4;

import java.util.List;
import java.util.Optional;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.User;

public interface AdminService {

	
	  public List<Admin> getAdmin();
	  
	  public void saveAdmin (Admin adminObj);
	  public Optional<Admin>  getAdminDetailsById(int adminNo);
	  public void updateAdminDetails(int adminNo ,Admin adminObj);
	  public void deleteAdmin(int adminNo);

	void saveUser(User uobj);

	Optional<User> getUserDetailsById(long uno);
}
