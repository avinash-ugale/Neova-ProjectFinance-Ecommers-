package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Product;
import com.example.demo.layer2.User;
@Repository
public class ProductRepoImpl extends BaseRepository implements ProductRepo {

	@Transactional
	public void insertProduct(Product productObj) {
		super.persist(productObj); 

	}

	@Override
	public Product selectProduct(int productNo) {
		Product product = super.find(Product.class,productNo);
		return product;
	}

	@Override
	public List<Product> selectProduct() {
		List<Product>  productList = new ArrayList<>();
		return super.findAll("Product");
	}

	@Transactional
	public void updateProduct(Product productObj) {
		super.merge(productObj);

	}

	@Transactional
	public void deletePerson(int productNo) {
		super.remove(Product.class, productNo);

	}

	@Transactional
	public void deleteProduct(int uno) {
		super.remove(Product.class, uno);

	}

}
