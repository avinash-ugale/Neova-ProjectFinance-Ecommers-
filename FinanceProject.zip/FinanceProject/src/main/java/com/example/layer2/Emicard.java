package com.example.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="")

public class Emicard {
	    
	    @Id
		@Column(name="EMI_INSTALLATION_NO")
		private int EmiInstallationNo;
		
		
		@Column(name="EMI_CARD_NO")
		private int EmiCardNo;
		
		@Column(name="PHONE_NO")
		private long PhoneNo;
		
		@Column(name="DATE_OF_PAYMENT")
		private LocalDate Date;
		
		@Column(name="AMOUNT_PAID")
		private long AmountPaid;
		
		@Column(name="COUNT_INSTALLMENT")
		private long CountInstallment;
		
		@Column(name="PAID_STATUS")
		private String PaidStatus;

		public int getEmiInstallationNo() {
			return EmiInstallationNo;
		}

		public void setEmiInstallationNo(int emiInstallationNo) {
			EmiInstallationNo = emiInstallationNo;
		}

		public int getEmiCardNo() {
			return EmiCardNo;
		}

		public void setEmiCardNo(int emiCardNo) {
			EmiCardNo = emiCardNo;
		}

		public long getPhoneNo() {
			return PhoneNo;
		}

		public void setPhoneNo(long phoneNo) {
			PhoneNo = phoneNo;
		}

		public LocalDate getDate() {
			return Date;
		}

		public void setDate(LocalDate date) {
			Date = date;
		}

		public long getAmountPaid() {
			return AmountPaid;
		}

		public void setAmountPaid(long amountPaid) {
			AmountPaid = amountPaid;
		}

		public long getCountInstallment() {
			return CountInstallment;
		}

		public void setCountInstallment(long countInstallment) {
			CountInstallment = countInstallment;
		}

		public String getPaidStatus() {
			return PaidStatus;
		}

		public void setPaidStatus(String paidStatus) {
			PaidStatus = paidStatus;
		}

		@Override
		public String toString() {
			return "Emicard [EmiInstallationNo=" + EmiInstallationNo + ", EmiCardNo=" + EmiCardNo + ", PhoneNo="
					+ PhoneNo + ", Date=" + Date + ", AmountPaid=" + AmountPaid + ", CountInstallment="
					+ CountInstallment + ", PaidStatus=" + PaidStatus + "]";
		}

	     
		
	    

}

