//package com.example.demo.layer4;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.example.demo.layer2.Admin;
//import com.example.demo.layer2.User;
//import com.example.demo.layer3.AdminRepo;
//
//public class AdminServiceImpl implements AdminService {
// @Autowired
//	AdminRepo adminRepo;
//	@Override
//	public List<Admin> getAdmin() {
//		// TODO Auto-generated method stub
//		return adminRepo.findAll();
//	}
//
//	@Override
//	public void saveUser(User uobj) {
//		adminRepo.save(uobj);
//
//	}
//
//	@Override
//	public Optional<User> getUserDetailsById(long uno) {
//		// TODO Auto-generated method stub
//		return adminRepo.findById(uno);
//	}
//
//	@Override
//	public void updateUserDetails(long uno, User uobj) {
//		uobj.setUserId(uno);
//		adminRepo.save(uobj);
//
//	}
//
//	@Override
//	public void deleteUser(long uno) {
//		adminRepo.deleteById(uno);
//	}
//
//}
