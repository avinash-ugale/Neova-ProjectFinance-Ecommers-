package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.PaymentAndInstallment;
import com.example.demo.layer3.PaymentAndInstallmentRepo;
import com.example.demo.layer3.PaymentAndInstallmentRepoImpl;

public class PaymentAndInstallmentServiceImpl implements PaymentAndInstallmentService {
	PaymentAndInstallmentRepoImpl paymentObj;
	@Override
	public void createPaymentAndInstallmentService(PaymentAndInstallment paymentAndInstallmentObj) {
		// TODO Auto-generated method stub
		paymentObj.insertInstallment(paymentAndInstallmentObj);
	}

	@Override
	public List<PaymentAndInstallment> findAllPaymentAndInstallmentService() {
		// TODO Auto-generated method stub
		return paymentObj.findAll("PaymentAndInstallment");
	}

	@Override
	public PaymentAndInstallment findPaymentAndInstallmentService(int paymentAndInstallmentNo) {
		// TODO Auto-generated method stub
		return paymentObj.selectInstallment(paymentAndInstallmentNo);
	}

	@Override
	public void modifyUserService(PaymentAndInstallment paymentAndInstallmentObj) {
		// TODO Auto-generated method stub
		paymentObj.updateInstallment(paymentAndInstallmentObj);
	}

	@Override
	public void removePaymentAndInstallmentService(int paymentAndInstallmentNo) {
		// TODO Auto-generated method stub
		paymentObj.deleteInstallment(paymentAndInstallmentNo);
	}

}
