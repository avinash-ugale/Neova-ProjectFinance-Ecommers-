package com.example.demo.layer2;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity

@Table(name = "cardtype_tb")
public class EMICard {

	public EMICard(String cardType, long costOfCard, long cardLimit) {
		super();
		this.cardType = cardType;
		this.costOfCard = costOfCard;
		this.cardLimit = cardLimit;
	}

	public EMICard() {
		super();
		// TODO Auto-generated constructor stub
	}



	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int cardTypeNo;
	private String cardType;
	private long costOfCard;
	private long cardLimit;
	@OneToOne//(mappedBy = "cardTypeNo", cascade = CascadeType.ALL)
	private User user;

	@OneToMany(mappedBy = "emiCard", cascade = CascadeType.ALL)
	private Set<EMI> userOrderSet = new HashSet<EMI>();
	
	
	

//







//
	

	public int getCardTypeNo() {
		return cardTypeNo;
	}
	public void setCardTypeNo(int cardTypeNo) {
		this.cardTypeNo = cardTypeNo;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public long getCostOfCard() {
		return costOfCard;
	}
	public void setCostOfCard(long costOfCard) {
		this.costOfCard = costOfCard;
	}
	public long getCardLimit() {
		return cardLimit;
	}
	public void setCardLimit(long cardLimit) {
		this.cardLimit = cardLimit;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Set<EMI> getUserOrderSet() {
		return userOrderSet;
	}
	public void setUserOrderSet(Set<EMI> userOrderSet) {
		this.userOrderSet = userOrderSet;
	}

	

	
}
