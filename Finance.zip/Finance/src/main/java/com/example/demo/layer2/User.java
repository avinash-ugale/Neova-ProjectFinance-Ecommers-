package com.example.demo.layer2;

import java.time.LocalDate;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_tb")
public class User {

	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int userId;
	private String userName;
	private LocalDate dateOfBirth;
	private long phoneNumber;
	private String email;
	private String password;
	private String address;
	private String panCard;
	private long cibilScore;
	private String bankName;
	private String ifsc;
	private long accountNumber;
	private String accountStatus;
	

	@OneToMany(mappedBy = "userOrderId", cascade = CascadeType.ALL)
	private Set<Orders> userOrderSet = new HashSet<Orders>();
	
	@OneToOne
	private EMICard emiCard;
	
	@OneToOne
	private EMI emi;
	
	@ManyToOne
	private User productUserId;
	@ManyToOne
	private Product productId;
	

	public User getProductUserId() {
		return productUserId;
	}
	public Product getProductId() {
		return productId;
	}
	public void setProductId(Product productId) {
		this.productId = productId;
	}
	public void setProductUserId(User productUserId) {
		this.productUserId = productUserId;
	}
	public Set<Orders> getUserOrderSet() {
		return userOrderSet;
	}
	public void setUserOrderSet(Set<Orders> userOrderSet) {
		this.userOrderSet = userOrderSet;
	}
	public EMI getEmi() {
		return emi;
	}
	public void setEmi(EMI emi) {
		this.emi = emi;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String userName, LocalDate dateOfBirth, long phoneNumber, String email, String password, String address,
			String panCard, String bankName, String ifsc, long accountNumber) {
		super();
		this.userName = userName;
		this.dateOfBirth = dateOfBirth;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.password = password;
		this.address = address;
		this.panCard = panCard;
		this.bankName = bankName;
		this.ifsc = ifsc;
		this.accountNumber =accountNumber ;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPanCard() {
		return panCard;
	}
	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}
	public long getCibilScore() {
		return cibilScore;
	}
	public void setCibilScore(long cibilScore) {
		this.cibilScore = cibilScore;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public EMICard getEmiCard() {
		return emiCard;
	}
	public void setEmiCard(EMICard emiCard) {
		this.emiCard = emiCard;
	}
	public void deleteUser(int i) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	

	
	
}
