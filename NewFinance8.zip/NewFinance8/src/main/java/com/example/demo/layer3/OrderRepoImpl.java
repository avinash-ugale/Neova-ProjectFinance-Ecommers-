package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Order;

import com.example.demo.layer2.Orders;
import com.example.demo.layer2.User;

public class OrderRepoImpl extends BaseRepository implements OrdersRepo {

	@Override
	public void insertOrder(Orders ordersObj) {
		super.persist(ordersObj); 

	}

	@Override
	public Orders selectOrder(int ordersno) {
		Orders order = super.find(Orders.class, ordersno);
		return order;
	}

	@Override
	public List<Orders> selectOrders() {
		List<Order>  userList = new ArrayList<>();
		return super.findAll("Orders");
	}

	@Override
	public void updateOrders(Orders ordersObj) {
		super.merge(ordersObj);

	}

	@Override
	public void deleteOrders(int ordersNo) {
		super.remove(User.class,ordersNo);

	}

}
