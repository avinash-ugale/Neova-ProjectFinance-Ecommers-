package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.Orders;
import com.example.demo.layer2.User;
import com.example.demo.layer3.OrdersRepoImpl;

public class OrdersServiceImpl implements OrdersService {
	OrdersRepoImpl orderRepo;
	@Override
	public void createOrdersService(Orders ordersObj) {
		// TODO Auto-generated method stub
		orderRepo.insertOrder(ordersObj);
	}

	@Override
	public List<Orders> findAllOrdersService() {
		// TODO Auto-generated method stub
		return orderRepo.findAll("Orders");
	}

	@Override
	public Orders findOrdersService(int OrdersNo) {
		// TODO Auto-generated method stub
		return orderRepo.selectOrder(OrdersNo);
	}

	@Override
	public void modifyOrdersService(Orders ordersObj) {
		// TODO Auto-generated method stub
		orderRepo.updateOrders(ordersObj);
	}

	@Override
	public void removeOrdersService(int ordersNo) {
		// TODO Auto-generated method stub
		orderRepo.deleteOrders(ordersNo);
	}

}
