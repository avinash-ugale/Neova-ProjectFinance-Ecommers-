package com.example.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.layer2.Emi;
import com.example.layer2.EmiCard;


@SpringBootTest
class DemoApplicationTest {


	@Test
	public void insertEmiCardDetails() 
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

		
		EmiCard emicard=new EmiCard();
		
		emicard.setCardLimit(30000);
		emicard.setCardType("current");
		emicard.setCostOfCard(40000);
	
	}
		/*
		@Test
		public void insertEmi() 
		{
			EntityManagerFactory entityManagerFactory = 
					Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
			
			System.out.println("Entity Manager Factory : "+entityManagerFactory);
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			//ctrl+shift+M
			
			System.out.println("Entity Manager : "+entityManager);
			
			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			
				Emi emi= new Emi();
				
				emi.setCardType("Titanium");
				emi.setEmiCardNo(23445657);
				emi.setRemainingBalance(20000);
			
			
		
			
			
			entityManager.persist(emi); //generate the insert query for us 
		transaction.commit();
	}
	*/

}
