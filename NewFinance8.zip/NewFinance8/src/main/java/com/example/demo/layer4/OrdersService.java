package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.Orders;
import com.example.demo.layer2.User;

public interface OrdersService {
	void createOrdersService(Orders ordersObj) ; //C
	List<Orders> findAllOrdersService(); //RA
	
	Orders findOrdersService(int OrdersNo);
	void modifyOrdersService(Orders ordersObj); //C
	void removeOrdersService(int ordersNo); //C
	
}
