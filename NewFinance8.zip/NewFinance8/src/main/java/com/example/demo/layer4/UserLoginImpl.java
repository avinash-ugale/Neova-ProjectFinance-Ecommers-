package com.example.demo.layer4;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.User;
import com.example.demo.layer3.UserRepoImpl;

public class UserLoginImpl implements UserLogin {
@Autowired
UserRepoImpl u;

	@Override
	public boolean userLogin(int userId,String password) {
		 User user =u.selectUser(userId);
		 if(user==null) {
		 return false;	 
		 }
		 else if ( user.getPassword()!=password) {
			 return false;
		}
			
		 else {
			 return true;
		 }

	}

}
