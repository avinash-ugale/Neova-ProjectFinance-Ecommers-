package com.example.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

    @Entity
    @Table(name="EmiCardTable")
    public class EmiCard {

            @Id
			@Column(name="CARD_TYPE")
			private String CardType;
			
			
			@Column(name="COST_OF_CARD")
			private float CostOfCard;
			
			@Column(name="CARD_LIMIT")
			private float CardLimit;
			 //One to one relation for EMicard table
			@OneToOne
			private User user;

			public User getUser() {
				return user;
			}

			public void setUser(User user) {
				this.user = user;
			}

			public String getCardType() {
				return CardType;
			}

			public void setCardType(String cardType) {
				CardType = cardType;
			}

			public float getCostOfCard() {
				return CostOfCard;
			}

			public void setCostOfCard(float costOfCard) {
				CostOfCard = costOfCard;
			}

			public float getCardLimit() {
				return CardLimit;
			}

			public void setCardLimit(float cardLimit) {
				CardLimit = cardLimit;
			}

			@Override
			public String toString() {
				return "EmiCard [CardType=" + CardType + ", CostOfCard=" + CostOfCard + ", CardLimit=" + CardLimit
						+ "]";
			}
			
    }   
