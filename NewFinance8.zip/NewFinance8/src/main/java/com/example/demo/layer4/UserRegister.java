package com.example.demo.layer4;

import com.example.demo.layer2.EMICard;
import com.example.demo.layer2.User;

public interface UserRegister {
	int createUser(User userObject);
	void selectEMICard(int userId,int cardId);
	
}
