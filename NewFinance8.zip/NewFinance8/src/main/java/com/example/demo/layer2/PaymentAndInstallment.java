package com.example.demo.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;
@Entity
@Table(name="installment_tb")
public class PaymentAndInstallment {
	public PaymentAndInstallment() {
		super();
		// TODO Auto-generated constructor stub
	}
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Id
	private int emiInstallmentNumber;
	private LocalDate	dateOFPayment;
	private float	amountPaid;
	private int	countOfInstallment;
	private float paidStatus;
	@ManyToOne
	private EMI emiCardNumber;
	@ManyToOne
	private Orders orderInstallmentId;
	//







	//

		
	public int getEmiInstallmentNumber() {
		return emiInstallmentNumber;
	}
	public void setEmiInstallmentNumber(int emiInstallmentNumber) {
		this.emiInstallmentNumber = emiInstallmentNumber;
	}
	public LocalDate getDateOFPayment() {
		return dateOFPayment;
	}
	public void setDateOFPayment(LocalDate dateOFPayment) {
		this.dateOFPayment = dateOFPayment;
	}
	public float getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(float amountPaid) {
		this.amountPaid = amountPaid;
	}
	public int getCountOfInstallment() {
		return countOfInstallment;
	}
	public void setCountOfInstallment(int countOfInstallment) {
		this.countOfInstallment = countOfInstallment;
	}
	public float getPaidStatus() {
		return paidStatus;
	}
	public void setPaidStatus(float paidStatus) {
		this.paidStatus = paidStatus;
	}
	public EMI getEmiCardNumber() {
		return emiCardNumber;
	}
	public void setEmiCardNumber(EMI emiCardNumber) {
		this.emiCardNumber = emiCardNumber;
	}
	public Orders getOrderInstallmentId() {
		return orderInstallmentId;
	}
	public void setOrderInstallmentId(Orders orderInstallmentId) {
		this.orderInstallmentId = orderInstallmentId;
	}
	public PaymentAndInstallment(LocalDate dateOFPayment, float amountPaid, int countOfInstallment, float paidStatus) {
		super();
		this.dateOFPayment = dateOFPayment;
		this.amountPaid = amountPaid;
		this.countOfInstallment = countOfInstallment;
		this.paidStatus = paidStatus;
	}



	
	

		
		
}
