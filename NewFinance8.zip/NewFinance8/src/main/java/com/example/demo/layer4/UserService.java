package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.User;
@Service
public interface UserService {

	void createUserService(User userObj) ; //C
	List<User> findAllUserService(); //RA
	
	User findUserService(int userno);
	void modifyUserService(int userno,User userObj); //C
	void removeUserService(int userNo); //C
		
}
