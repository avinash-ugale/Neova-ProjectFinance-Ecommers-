package com.example.demo;

import java.time.LocalDate;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Orders;
import com.example.demo.layer2.User;
import com.example.demo.layer3.OrdersRepoImpl;
import com.example.demo.layer3.UserRepoImpl;



		@SpringBootTest
		public class OneToManyTestUserToOrder {
		
			@Autowired
			UserRepoImpl user;
			@Autowired
			OrdersRepoImpl order;
			
		
		
		@Test
		void OneToManyTests() {
		
		User passObj1 = user.selectUser(31);
		
		Orders passObj2 = new Orders();
		
		passObj2.setUserOrderId(passObj1);
		
		order.insertOrder(passObj2);

}

}