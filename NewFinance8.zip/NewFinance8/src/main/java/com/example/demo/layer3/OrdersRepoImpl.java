package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Order;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Orders;
import com.example.demo.layer2.User;

@Repository
public class OrdersRepoImpl extends BaseRepository implements OrdersRepo {

	@Transactional
	public void insertOrder(Orders ordersObj) {
		super.persist(ordersObj);

	}

	@Override
	public Orders selectOrder(int ordersno) {
		Orders order = super.find(Orders.class, ordersno);
		return order;
	}

	@Override
	public List<Orders> selectOrders() {
		List<Order> orList = new ArrayList<>();
		return super.findAll("Orders");
	}

	@Transactional
	public void updateOrders(Orders ordersObj) {
		super.merge(ordersObj);

	}

	@Transactional
	public void deleteOrders(int ordersNo) {
		super.remove(User.class, ordersNo);

	}

	public List<Orders> selectOrdersByUserId(int userId) {

		List<Orders> ordersList = super.findAll("Order");

		List<Orders> userOrdersList = new ArrayList<>();
		for (Orders order1 : ordersList) {
			User a = order1.getUserOrderId(); 
			if (userId == a.getUserId()) {
				userOrdersList.add(order1);

			}
		}
		return userOrdersList;

	}

}
