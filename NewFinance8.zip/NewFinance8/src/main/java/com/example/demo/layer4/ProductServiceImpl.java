package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.Product;
import com.example.demo.layer3.ProductRepoImpl;

public class ProductServiceImpl implements ProductService {

	ProductRepoImpl productRepo;
	@Override
	public void createProductService(Product productObj) {
		
		// TODO Auto-generated method stub
		productRepo.insertProduct(productObj);
	}

	@Override
	public List<Product> findAllProductService() {
		// TODO Auto-generated method stub
		return	productRepo.findAll("Product") ;
	}

	@Override
	public Product findProductService(int productNo) {
		// TODO Auto-generated method stub
		return productRepo.selectProduct(productNo);
	}

	@Override
	public void modifyProductService(Product productObj) {
		// TODO Auto-generated method stub
		productRepo.updateProduct(productObj);
	}

	@Override
	public void removeProductService(int productNo) {
		// TODO Auto-generated method stub
		productRepo.deletePerson(productNo);
	}

}
