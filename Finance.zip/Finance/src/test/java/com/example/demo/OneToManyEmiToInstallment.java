package com.example.demo;

import java.time.LocalDate;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.EMI;
import com.example.demo.layer2.Orders;
import com.example.demo.layer2.PaymentAndInstallment;
import com.example.demo.layer2.User;
import com.example.demo.layer3.EMIRepoImpl;
import com.example.demo.layer3.OrdersRepoImpl;
import com.example.demo.layer3.PaymentAndInstallmentRepo;
import com.example.demo.layer3.UserRepoImpl;



		@SpringBootTest
		public class OneToManyEmiToInstallment {
		
			@Autowired
			EMIRepoImpl emi;
			@Autowired
			PaymentAndInstallmentRepo payment;
			
		
		
		@Test
		void OneToManyTests() {
		
		EMI passObj1 = emi.selectEMI(48);
		
		PaymentAndInstallment passObj2 = new PaymentAndInstallment();
		
		passObj2.setEmiCardNumber(passObj1);
		
		payment.insertInstallment(passObj2);

}

}