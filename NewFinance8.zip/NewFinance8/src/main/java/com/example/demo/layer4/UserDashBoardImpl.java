package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.EMICard;
import com.example.demo.layer2.Orders;
import com.example.demo.layer2.User;
import com.example.demo.layer3.OrdersRepoImpl;
import com.example.demo.layer3.UserRepoImpl;

public class UserDashBoardImpl implements UserDashBoard {
	@Autowired
	UserRepoImpl u;
	@Autowired
	OrdersRepoImpl o;
	@Override
	public EMICard cardDetails(int userId) {
		User user=	u.selectUser(userId);
			
		return null;
	}

	@Override
	public Set<Orders> ordersDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public float remainingBalance() {
		// TODO Auto-generated method stub
		return 0;
	}

}
