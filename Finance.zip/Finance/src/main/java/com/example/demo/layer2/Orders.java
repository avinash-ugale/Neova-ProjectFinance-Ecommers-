package com.example.demo.layer2;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orders_tb")

public class Orders {


	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Orders(LocalDate orderDate, String emiScheme) {
		super();
		this.orderDate = orderDate;
		this.emiScheme = emiScheme;
	}


	@Id

	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int orderId;

	private LocalDate orderDate;
	private String emiScheme;

	@ManyToOne
	private User userOrderId;
	@ManyToOne
	private Product productId;

	@OneToMany(mappedBy = "orderInstallmentId", cascade = CascadeType.ALL)
	private Set<PaymentAndInstallment> userInstallmentSet = new HashSet<PaymentAndInstallment>();
	//

	//

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getEmiScheme() {
		return emiScheme;
	}

	public void setEmiScheme(String emiScheme) {
		this.emiScheme = emiScheme;
	}

	public User getUserOrderId() {
		return userOrderId;
	}

	public void setUserOrderId(User userOrderId) {
		this.userOrderId = userOrderId;
	}

	public Product getProductId() {
		return productId;
	}

	public void setProductId(Product productId) {
		this.productId = productId;
	}

	public Set<PaymentAndInstallment> getUserInstallmentSet() {
		return userInstallmentSet;
	}

	public void setUserInstallmentSet(Set<PaymentAndInstallment> userInstallmentSet) {
		this.userInstallmentSet = userInstallmentSet;
	}

}
