package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.PaymentAndInstallment;
import com.example.demo.layer2.User;
import com.fasterxml.jackson.databind.deser.Deserializers.Base;
@Repository
public class PaymentAndInstallmentRepoImpl extends BaseRepository implements PaymentAndInstallmentRepo {

	@Transactional
	public void insertInstallment(PaymentAndInstallment installmentobj) {
		super.persist(installmentobj); 

	}

	@Override
	public PaymentAndInstallment selectInstallment(int installmentNo) {
		PaymentAndInstallment installment = super.find(PaymentAndInstallment.class,installmentNo);
		return installment;
	}

	@Override
	public List<PaymentAndInstallment> selectInstallment() {
		List<PaymentAndInstallment>  userList = new ArrayList<>();
		return super.findAll("PaymentAndInstallment");
	}

	@Transactional
	public void updateInstallment(PaymentAndInstallment installmentobj) {
		super.merge(installmentobj);
	}

	@Transactional
	public void deleteInstallment(int installmentNo) {
		super.remove(User.class, installmentNo);

	}


}
