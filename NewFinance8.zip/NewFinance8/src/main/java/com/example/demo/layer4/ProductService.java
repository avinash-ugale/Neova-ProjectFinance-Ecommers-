package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.Product;
import com.example.demo.layer2.User;

public interface ProductService {
	void createProductService(Product productObj) ; //C
	List<Product> findAllProductService(); //RA
	
	Product findProductService(int productNo);
	void modifyProductService(Product productObj); //C
	void removeProductService(int productNo); //C
	
}
