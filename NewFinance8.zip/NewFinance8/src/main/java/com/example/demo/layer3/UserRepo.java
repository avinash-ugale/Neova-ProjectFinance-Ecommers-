package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.User;
@Repository
public interface UserRepo  {
	void insertUser(User uobj); // C

	User selectUser(int uno); // R

	List<User> selectUsers(); // RA

	void updateUser(User uobj); // U

	void deleteUser(int uno); // D
}
