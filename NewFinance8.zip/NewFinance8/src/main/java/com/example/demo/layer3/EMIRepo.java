package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.EMI;
import com.example.demo.layer2.Orders;
@Repository
public interface EMIRepo {
	void insertEMI(EMI emiObj); // C

	EMI selectEMI(int emino); // R

	List<EMI> selectEMIs(); // RA

	void updateEMI(EMI emiObj); // U

	void deleteEMI(int emino); // D
}
