package com.example.demo.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.EMI;
@Repository
public class EMIRepoImpl extends BaseRepository implements EMIRepo {

	@Transactional
	public void insertEMI(EMI emiObj) {
		// TODO Auto-generated method stub
			super.persist(emiObj);
	}

	@Override
	public EMI selectEMI(int emino) {
		// TODO Auto-generated method stub
		return super.find(EMI.class,emino);
	}

	@Override
	public List<EMI> selectEMIs() {
		// TODO Auto-generated method stub
		return super.findAll("EMI");
	}

	@Transactional
	public void updateEMI(EMI emiObj) {
			
		// TODO Auto-generated method stub
		super.merge(emiObj);
	}

	@Transactional
	public void deleteEMI(int emino) {
		// TODO Auto-generated method stub
			super.remove(EMI.class,emino);
	}

}
