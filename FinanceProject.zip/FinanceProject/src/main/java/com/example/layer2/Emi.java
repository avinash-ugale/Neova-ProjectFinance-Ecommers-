package com.example.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.example.layer2.User;

    @Entity
    @Table(name="EmiTable")
    public class Emi {

            @Id
			@Column(name="EMI_CARD_NO")
			private int EmiCardNo;
			
			
			@Column(name="REMAINING_BALANCE")
			private float RemainingBalance;
			
			/*@Column(name="EXPIRATION_DATE")
			private LocalDate ExpirationDate;*/
			
			@Column(name="CARD_TYPE")
			private String CardType;

			
			@OneToOne
			private User user;
			
			public User getUser() {
				return user;
			}

			public void setUser(User user) {
				this.user = user;
			}

			public int getEmiCardNo() {
				return EmiCardNo;
			}

			public void setEmiCardNo(int emiCardNo) {
				EmiCardNo = emiCardNo;
			}

			public float getRemainingBalance() {
				return RemainingBalance;
			}

			public void setRemainingBalance(float remainingBalance) {
				RemainingBalance = remainingBalance;
			}

		/*	public LocalDate getExpirationDate() {
				return ExpirationDate;
			}

			public void setExpirationDate(LocalDate expirationDate) {
				ExpirationDate = expirationDate;
			}
       */
			public String getCardType() {
				return CardType;
			}

			public void setCardType(String cardType) {
				CardType = cardType;
			}

			@Override
			public String toString() {
				return "Emi [EmiCardNo=" + EmiCardNo + ", RemainingBalance=" + RemainingBalance + ", ExpirationDate="
						/*+ ExpirationDate*/ + ", CardType=" + CardType + "]";
			}
			
    }	
