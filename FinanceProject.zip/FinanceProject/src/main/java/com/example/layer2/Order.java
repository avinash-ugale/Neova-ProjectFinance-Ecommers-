package com.example.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

    @Entity
    @Table(name="")
    public class Order {

            @Id
			@Column(name="ORDER_ID")
			private int OrderId;
			
			
			@Column(name="USER_ID")
			private int UserId;
			
			@Column(name="BANK_NAME")
			private String BankName;
			
			@Column(name="PRODUCT_ID")
			private int ProductId;
			
			@Column(name="ORDER_DATE")
			private LocalDate OrderDate;
            
			
			@Column(name="EMI_SCHEME")
			private String EmiScheme;


			public int getOrderId() {
				return OrderId;
			}


			public void setOrderId(int orderId) {
				OrderId = orderId;
			}


			public int getUserId() {
				return UserId;
			}


			public void setUserId(int userId) {
				UserId = userId;
			}


			public String getBankName() {
				return BankName;
			}


			public void setBankName(String bankName) {
				BankName = bankName;
			}


			public int getProductId() {
				return ProductId;
			}


			public void setProductId(int productId) {
				ProductId = productId;
			}


			public LocalDate getOrderDate() {
				return OrderDate;
			}


			public void setOrderDate(LocalDate orderDate) {
				OrderDate = orderDate;
			}


			public String getEmiScheme() {
				return EmiScheme;
			}


			public void setEmiScheme(String emiScheme) {
				EmiScheme = emiScheme;
			}


			@Override
			public String toString() {
				return "Order [OrderId=" + OrderId + ", UserId=" + UserId + ", BankName=" + BankName + ", ProductId="
						+ ProductId + ", OrderDate=" + OrderDate + ", EmiScheme=" + EmiScheme + "]";
			}

            
		    

	}


