package com.example.demo.layer4;

import java.util.List;

import com.example.demo.layer2.PaymentAndInstallment;
import com.example.demo.layer2.User;

public interface PaymentAndInstallmentService {
	void createPaymentAndInstallmentService(PaymentAndInstallment paymentAndInstallmentObj) ; //C
	List<PaymentAndInstallment> findAllPaymentAndInstallmentService(); //RA
	
	PaymentAndInstallment findPaymentAndInstallmentService(int paymentAndInstallmentNo);
	void modifyUserService(PaymentAndInstallment paymentAndInstallmentObj); //C
	void removePaymentAndInstallmentService(int paymentAndInstallmentNo); //C
	
}
